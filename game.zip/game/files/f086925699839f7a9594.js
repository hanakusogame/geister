function _typeof(obj) { "@babel/helpers - typeof"; if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") { _typeof = function _typeof(obj) { return typeof obj; }; } else { _typeof = function _typeof(obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; } return _typeof(obj); }

(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;

    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }

    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }

          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }

        return n[i].exports;
      }

      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) {
        o(t[i]);
      }

      return o;
    }

    return r;
  }()({
    1: [function (require, module, exports) {
      "use strict";

      var ActionType;

      (function (ActionType) {
        ActionType[ActionType["Wait"] = 0] = "Wait";
        ActionType[ActionType["Call"] = 1] = "Call";
        ActionType[ActionType["TweenTo"] = 2] = "TweenTo";
        ActionType[ActionType["TweenBy"] = 3] = "TweenBy";
        ActionType[ActionType["TweenByMult"] = 4] = "TweenByMult";
        ActionType[ActionType["Cue"] = 5] = "Cue";
        ActionType[ActionType["Every"] = 6] = "Every";
      })(ActionType || (ActionType = {}));

      module.exports = ActionType;
    }, {}],
    2: [function (require, module, exports) {
      "use strict";
      /**
       * Easing関数群。
       * 参考: http://gizma.com/easing/
       */

      var Easing;

      (function (Easing) {
        /**
         * 入力値をlinearした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */
        function linear(t, b, c, d) {
          return c * t / d + b;
        }

        Easing.linear = linear;
        /**
         * 入力値をeaseInQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuad(t, b, c, d) {
          t /= d;
          return c * t * t + b;
        }

        Easing.easeInQuad = easeInQuad;
        /**
         * 入力値をeaseOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuad(t, b, c, d) {
          t /= d;
          return -c * t * (t - 2) + b;
        }

        Easing.easeOutQuad = easeOutQuad;
        /**
         * 入力値をeaseInOutQuadした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuad(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t + b;
          --t;
          return -c / 2 * (t * (t - 2) - 1) + b;
        }

        Easing.easeInOutQuad = easeInOutQuad;
        /**
         * 入力値をeaseInQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCubic(t, b, c, d) {
          t /= d;
          return c * t * t * t + b;
        }

        Easing.easeInCubic = easeInCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInCubic` を用いるべきである。
         */

        Easing.easeInQubic = easeInCubic;
        /**
         * 入力値をeaseOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCubic(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t + 1) + b;
        }

        Easing.easeOutCubic = easeOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeOutCubic` を用いるべきである。
         */

        Easing.easeOutQubic = easeOutCubic;
        /**
         * 入力値をeaseInOutQubicした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCubic(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t + 2) + b;
        }

        Easing.easeInOutCubic = easeInOutCubic;
        /**
         * @deprecated この関数は非推奨機能である。代わりに `easeInOutCubic` を用いるべきである。
         */

        Easing.easeInOutQubic = easeInOutCubic;
        /**
         * 入力値をeaseInQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuart(t, b, c, d) {
          t /= d;
          return c * t * t * t * t + b;
        }

        Easing.easeInQuart = easeInQuart;
        /**
         * 入力値をeaseOutQuartした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuart(t, b, c, d) {
          t /= d;
          --t;
          return -c * (t * t * t * t - 1) + b;
        }

        Easing.easeOutQuart = easeOutQuart;
        /**
         * 入力値をeaseInQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInQuint(t, b, c, d) {
          t /= d;
          return c * t * t * t * t * t + b;
        }

        Easing.easeInQuint = easeInQuint;
        /**
         * 入力値をeaseOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutQuint(t, b, c, d) {
          t /= d;
          --t;
          return c * (t * t * t * t * t + 1) + b;
        }

        Easing.easeOutQuint = easeOutQuint;
        /**
         * 入力値をeaseInOutQuintした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutQuint(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * t * t * t * t * t + b;
          t -= 2;
          return c / 2 * (t * t * t * t * t + 2) + b;
        }

        Easing.easeInOutQuint = easeInOutQuint;
        /**
         * 入力値をeaseInSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInSine(t, b, c, d) {
          return -c * Math.cos(t / d * (Math.PI / 2)) + c + b;
        }

        Easing.easeInSine = easeInSine;
        /**
         * 入力値をeaseOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutSine(t, b, c, d) {
          return c * Math.sin(t / d * (Math.PI / 2)) + b;
        }

        Easing.easeOutSine = easeOutSine;
        /**
         * 入力値をeaseInOutSineした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutSine(t, b, c, d) {
          return -c / 2 * (Math.cos(Math.PI * t / d) - 1) + b;
        }

        Easing.easeInOutSine = easeInOutSine;
        /**
         * 入力値をeaseInExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInExpo(t, b, c, d) {
          return c * Math.pow(2, 10 * (t / d - 1)) + b;
        }

        Easing.easeInExpo = easeInExpo;
        /**
         * 入力値をeaseInOutExpoした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutExpo(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return c / 2 * Math.pow(2, 10 * (t - 1)) + b;
          --t;
          return c / 2 * (-Math.pow(2, -10 * t) + 2) + b;
        }

        Easing.easeInOutExpo = easeInOutExpo;
        /**
         * 入力値をeaseInCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInCirc(t, b, c, d) {
          t /= d;
          return -c * (Math.sqrt(1 - t * t) - 1) + b;
        }

        Easing.easeInCirc = easeInCirc;
        /**
         * 入力値をeaseOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeOutCirc(t, b, c, d) {
          t /= d;
          --t;
          return c * Math.sqrt(1 - t * t) + b;
        }

        Easing.easeOutCirc = easeOutCirc;
        /**
         * 入力値をeaseInOutCircした結果の現在位置を返す。
         * @param t 経過時間
         * @param b 開始位置
         * @param c 終了位置
         * @param d 所要時間
         */

        function easeInOutCirc(t, b, c, d) {
          t /= d / 2;
          if (t < 1) return -c / 2 * (Math.sqrt(1 - t * t) - 1) + b;
          t -= 2;
          return c / 2 * (Math.sqrt(1 - t * t) + 1) + b;
        }

        Easing.easeInOutCirc = easeInOutCirc;
      })(Easing || (Easing = {}));

      module.exports = Easing;
    }, {}],
    3: [function (require, module, exports) {
      "use strict";

      var Tween = require("./Tween");
      /**
       * タイムライン機能を提供するクラス。
       */


      var Timeline =
      /** @class */
      function () {
        /**
         * Timelineを生成する。
         * @param scene タイムラインを実行する `Scene`
         */
        function Timeline(scene) {
          this._scene = scene;
          this._tweens = [];
          this._fps = this._scene.game.fps;
          this.paused = false;
          scene.update.add(this._handler, this);
        }
        /**
         * Timelineに紐付いたTweenを生成する。
         * @param target タイムライン処理の対象にするオブジェクト
         * @param option Tweenの生成オプション。省略された場合、 {modified: target.modified, destroyed: target.destroyed} が与えられた時と同様の処理を行う。
         */


        Timeline.prototype.create = function (target, option) {
          var t = new Tween(target, option);

          this._tweens.push(t);

          return t;
        };
        /**
         * Timelineに紐付いたTweenを削除する。
         * @param tween 削除するTween。
         */


        Timeline.prototype.remove = function (tween) {
          var index = this._tweens.indexOf(tween);

          if (index < 0) {
            return;
          }

          this._tweens.splice(index, 1);
        };
        /**
         * Timelineに紐付いた全Tweenの紐付けを解除する。
         */


        Timeline.prototype.clear = function () {
          this._tweens.length = 0;
        };
        /**
         * このTimelineを破棄する。
         */


        Timeline.prototype.destroy = function () {
          this._tweens.length = 0;

          if (!this._scene.destroyed()) {
            this._scene.update.remove(this._handler, this);
          }

          this._scene = undefined;
        };
        /**
         * このTimelineが破棄済みであるかを返す。
         */


        Timeline.prototype.destroyed = function () {
          return this._scene === undefined;
        };

        Timeline.prototype._handler = function () {
          if (this._tweens.length === 0 || this.paused) {
            return;
          }

          var tmp = [];

          for (var i = 0; i < this._tweens.length; ++i) {
            var tween = this._tweens[i];

            if (!tween.isFinished()) {
              tween._fire(1000 / this._fps);

              tmp.push(tween);
            }
          }

          this._tweens = tmp;
        };

        return Timeline;
      }();

      module.exports = Timeline;
    }, {
      "./Tween": 4
    }],
    4: [function (require, module, exports) {
      "use strict";

      var Easing = require("./Easing");

      var ActionType = require("./ActionType");
      /**
       * オブジェクトの状態を変化させるアクションを定義するクラス。
       * 本クラスのインスタンス生成には`Timeline#create()`を利用する。
       */


      var Tween =
      /** @class */
      function () {
        /**
         * Tweenを生成する。
         * @param target 対象となるオブジェクト
         * @param option オプション
         */
        function Tween(target, option) {
          this._target = target;
          this._stepIndex = 0;
          this._loop = !!option && !!option.loop;
          this._modifiedHandler = undefined;

          if (option && option.modified) {
            this._modifiedHandler = option.modified;
          } else if (target && target.modified) {
            this._modifiedHandler = target.modified;
          }

          this._destroyedHandler = undefined;

          if (option && option.destroyed) {
            this._destroyedHandler = option.destroyed;
          } else if (target && target.destroyed) {
            this._destroyedHandler = target.destroyed;
          }

          this._steps = [];
          this._lastStep = undefined;
          this._pararel = false;
          this.paused = false;
        }
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.to = function (props, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: ActionType.TweenTo,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * オブジェクトの状態を変化させるアクションを追加する。
         * 変化内容はアクション開始時を基準とした相対値で指定する。
         * @param props 変化内容
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         * @param multiply `true`を指定すると`props`の値をアクション開始時の値に掛け合わせた値が終了値となる（指定しない場合は`false`）
         */


        Tween.prototype.by = function (props, duration, easing, multiply) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          if (multiply === void 0) {
            multiply = false;
          }

          var type = multiply ? ActionType.TweenByMult : ActionType.TweenBy;
          var action = {
            input: props,
            duration: duration,
            easing: easing,
            type: type,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 次に追加されるアクションを、このメソッド呼び出しの直前に追加されたアクションと並列に実行させる。
         * `Tween#con()`で並列実行を指定されたアクションが全て終了後、次の並列実行を指定されていないアクションを実行する。
         */


        Tween.prototype.con = function () {
          this._pararel = true;
          return this;
        };
        /**
         * オブジェクトの変化を停止するアクションを追加する。
         * @param duration 停止する時間（ミリ秒）
         */


        Tween.prototype.wait = function (duration) {
          var action = {
            duration: duration,
            type: ActionType.Wait,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 関数を即座に実行するアクションを追加する。
         * @param func 実行する関数
         */


        Tween.prototype.call = function (func) {
          var action = {
            func: func,
            type: ActionType.Call,
            duration: 0,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 一時停止するアクションを追加する。
         * 内部的には`Tween#call()`で`Tween#paused`に`true`をセットしている。
         */


        Tween.prototype.pause = function () {
          var _this = this;

          return this.call(function () {
            _this.paused = true;
          });
        };
        /**
         * 待機時間をキーとして実行したい関数を複数指定する。
         * @param actions 待機時間をキーとして実行したい関数を値としたオブジェクト
         */


        Tween.prototype.cue = function (funcs) {
          var keys = Object.keys(funcs);
          keys.sort(function (a, b) {
            return Number(a) > Number(b) ? 1 : -1;
          });
          var q = [];

          for (var i = 0; i < keys.length; ++i) {
            q.push({
              time: Number(keys[i]),
              func: funcs[keys[i]]
            });
          }

          var action = {
            type: ActionType.Cue,
            duration: Number(keys[keys.length - 1]),
            cue: q,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * 指定した時間を経過するまで毎フレーム指定した関数を呼び出すアクションを追加する。
         * @param func 毎フレーム呼び出される関数。第一引数は経過時間、第二引数はEasingした結果の変化量（0-1）となる。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.every = function (func, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          var action = {
            func: func,
            type: ActionType.Every,
            easing: easing,
            duration: duration,
            initialized: false
          };

          this._push(action);

          return this;
        };
        /**
         * ターゲットをフェードインさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeIn = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 1
          }, duration, easing);
        };
        /**
         * ターゲットをフェードアウトさせるアクションを追加する。
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.fadeOut = function (duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            opacity: 0
          }, duration, easing);
        };
        /**
         * ターゲットを指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveTo = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した相対座標に移動するアクションを追加する。相対座標の基準値はアクション開始時の座標となる。
         * @param x x座標
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveBy = function (x, y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            x: x,
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットのX座標を指定した座標に移動するアクションを追加する。
         * @param x x座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveX = function (x, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            x: x
          }, duration, easing);
        };
        /**
         * ターゲットのY座標を指定した座標に移動するアクションを追加する。
         * @param y y座標
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.moveY = function (y, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            y: y
          }, duration, easing);
        };
        /**
         * ターゲットを指定した角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateTo = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットをアクション開始時の角度を基準とした相対角度に回転するアクションを追加する。
         * @param angle 角度
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.rotateBy = function (angle, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            angle: angle
          }, duration, easing);
        };
        /**
         * ターゲットを指定した倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleTo = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.to({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing);
        };
        /**
         * ターゲットのアクション開始時の倍率に指定した倍率を掛け合わせた倍率に拡縮するアクションを追加する。
         * @param scaleX X方向の倍率
         * @param scaleY Y方向の倍率
         * @param duration 変化に要する時間（ミリ秒）
         * @param easing Easing関数（指定しない場合は`Easing.linear`）
         */


        Tween.prototype.scaleBy = function (scaleX, scaleY, duration, easing) {
          if (easing === void 0) {
            easing = Easing.linear;
          }

          return this.by({
            scaleX: scaleX,
            scaleY: scaleY
          }, duration, easing, true);
        };
        /**
         * アニメーションが終了しているかどうかを返す。
         * `_target`が破棄された場合又は、全アクションの実行が終了した場合に`true`を返す。
         */


        Tween.prototype.isFinished = function () {
          var ret = false;

          if (this._destroyedHandler) {
            ret = this._destroyedHandler.call(this._target);
          }

          if (!ret) {
            ret = this._stepIndex !== 0 && this._stepIndex >= this._steps.length && !this._loop;
          }

          return ret;
        };
        /**
         * アニメーションを実行する。
         * @param delta 前フレームからの経過時間
         */


        Tween.prototype._fire = function (delta) {
          if (this._steps.length === 0 || this.isFinished() || this.paused) {
            return;
          }

          if (this._stepIndex >= this._steps.length) {
            if (this._loop) {
              this._stepIndex = 0;
            } else {
              return;
            }
          }

          var actions = this._steps[this._stepIndex];
          var remained = false;

          for (var i = 0; i < actions.length; ++i) {
            var action = actions[i];

            if (!action.initialized) {
              this._initAction(action);
            }

            if (action.finished) {
              continue;
            }

            action.elapsed += delta;

            switch (action.type) {
              case ActionType.Call:
                action.func.call(this._target);
                break;

              case ActionType.Every:
                var progress = action.easing(action.elapsed, 0, 1, action.duration);

                if (progress > 1) {
                  progress = 1;
                }

                action.func.call(this._target, action.elapsed, progress);
                break;

              case ActionType.TweenTo:
              case ActionType.TweenBy:
              case ActionType.TweenByMult:
                var keys = Object.keys(action.goal);

                for (var j = 0; j < keys.length; ++j) {
                  var key = keys[j];

                  if (action.elapsed >= action.duration) {
                    this._target[key] = action.goal[key];
                  } else {
                    this._target[key] = action.easing(action.elapsed, action.start[key], action.goal[key] - action.start[key], action.duration);
                  }
                }

                break;

              case ActionType.Cue:
                var cueAction = action.cue[action.cueIndex];

                if (cueAction !== undefined && action.elapsed >= cueAction.time) {
                  cueAction.func.call(this._target);
                  ++action.cueIndex;
                }

                break;
            }

            if (this._modifiedHandler) {
              this._modifiedHandler.call(this._target);
            }

            if (action.elapsed >= action.duration) {
              action.finished = true;
            } else {
              remained = true;
            }
          }

          if (!remained) {
            for (var k = 0; k < actions.length; ++k) {
              actions[k].initialized = false;
            }

            ++this._stepIndex;
          }
        };
        /**
         * Tweenの実行状態をシリアライズして返す。
         */


        Tween.prototype.serializeState = function () {
          var tData = {
            _stepIndex: this._stepIndex,
            _steps: []
          };

          for (var i = 0; i < this._steps.length; ++i) {
            tData._steps[i] = [];

            for (var j = 0; j < this._steps[i].length; ++j) {
              tData._steps[i][j] = {
                input: this._steps[i][j].input,
                start: this._steps[i][j].start,
                goal: this._steps[i][j].goal,
                duration: this._steps[i][j].duration,
                elapsed: this._steps[i][j].elapsed,
                type: this._steps[i][j].type,
                cueIndex: this._steps[i][j].cueIndex,
                initialized: this._steps[i][j].initialized,
                finished: this._steps[i][j].finished
              };
            }
          }

          return tData;
        };
        /**
         * Tweenの実行状態を復元する。
         * @param serializedstate 復元に使う情報。
         */


        Tween.prototype.deserializeState = function (serializedState) {
          this._stepIndex = serializedState._stepIndex;

          for (var i = 0; i < serializedState._steps.length; ++i) {
            for (var j = 0; j < serializedState._steps[i].length; ++j) {
              if (!serializedState._steps[i][j] || !this._steps[i][j]) continue;
              this._steps[i][j].input = serializedState._steps[i][j].input;
              this._steps[i][j].start = serializedState._steps[i][j].start;
              this._steps[i][j].goal = serializedState._steps[i][j].goal;
              this._steps[i][j].duration = serializedState._steps[i][j].duration;
              this._steps[i][j].elapsed = serializedState._steps[i][j].elapsed;
              this._steps[i][j].type = serializedState._steps[i][j].type;
              this._steps[i][j].cueIndex = serializedState._steps[i][j].cueIndex;
              this._steps[i][j].initialized = serializedState._steps[i][j].initialized;
              this._steps[i][j].finished = serializedState._steps[i][j].finished;
            }
          }
        };
        /**
         * `this._pararel`が`false`の場合は新規にステップを作成し、アクションを追加する。
         * `this._pararel`が`true`の場合は最後に作成したステップにアクションを追加する。
         */


        Tween.prototype._push = function (action) {
          if (this._pararel) {
            this._lastStep.push(action);
          } else {
            var index = this._steps.push([action]) - 1;
            this._lastStep = this._steps[index];
          }

          this._pararel = false;
        };

        Tween.prototype._initAction = function (action) {
          action.elapsed = 0;
          action.start = {};
          action.goal = {};
          action.cueIndex = 0;
          action.finished = false;
          action.initialized = true;

          if (action.type !== ActionType.TweenTo && action.type !== ActionType.TweenBy && action.type !== ActionType.TweenByMult) {
            return;
          }

          var keys = Object.keys(action.input);

          for (var i = 0; i < keys.length; ++i) {
            var key = keys[i];

            if (this._target[key] !== undefined) {
              action.start[key] = this._target[key];

              if (action.type === ActionType.TweenTo) {
                action.goal[key] = action.input[key];
              } else if (action.type === ActionType.TweenBy) {
                action.goal[key] = action.start[key] + action.input[key];
              } else if (action.type === ActionType.TweenByMult) {
                action.goal[key] = action.start[key] * action.input[key];
              }
            }
          }
        };

        return Tween;
      }();

      module.exports = Tween;
    }, {
      "./ActionType": 1,
      "./Easing": 2
    }],
    5: [function (require, module, exports) {
      "use strict";

      Object.defineProperty(exports, "__esModule", {
        value: true
      });
      exports.Timeline = require("./Timeline");
      exports.Tween = require("./Tween");
      exports.Easing = require("./Easing");
    }, {
      "./Easing": 2,
      "./Timeline": 3,
      "./Tween": 4
    }],
    6: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Ghost =
      /** @class */
      function (_super) {
        __extends(Ghost, _super);

        function Ghost(scene) {
          var _this = _super.call(this, {
            scene: scene,
            width: 55,
            height: 55
          }) || this;

          _this.num = 0;
          _this.turn = 0;

          _this.init = function (turn, num) {};

          _this.hideMask = function () {};
          /*
          const ghost = new g.FilledRect({
              scene: scene,
              width: 55,
              height: 55,
              cssColor: "cyan",
              local: true,
              opacity:0.2
          });
          this.append(ghost);
          */


          var player = new g.FrameSprite({
            scene: scene,
            src: scene.assets["ghost2"],
            width: 55,
            height: 66,
            y: -18,
            interval: 300,
            frames: [4, 5]
          });
          player.hide();

          _this.append(player);

          player.start();
          _this.player = player; //マスク

          var mask = new g.E({
            scene: scene,
            local: true
          });
          _this.mask = mask;
          var sprMask = new g.FrameSprite({
            scene: scene,
            src: scene.assets["ghost2"],
            width: 55,
            height: 66,
            y: -18,
            interval: 300,
            frames: [0, 1]
          });
          mask.append(sprMask);
          sprMask.start();

          _this.append(mask);

          _this.init = function (turn, num) {
            _this.turn = turn;
            _this.num = num;
            var n = 4 + turn * 2 + num * 4;
            player.frames = [n, n + 1];
            sprMask.frames = [turn * 2, turn * 2 + 1];
          };

          _this.hideMask = function () {
            player.show();
            mask.hide();
          };

          return _this;
        }

        return Ghost;
      }(g.E);

      exports.Ghost = Ghost;
    }, {}],
    7: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      });

      var Map =
      /** @class */
      function (_super) {
        __extends(Map, _super);

        function Map() {
          var _this = _super !== null && _super.apply(this, arguments) || this;

          _this.ghost = null;
          _this.num = 0;
          return _this;
        }

        return Map;
      }(g.FrameSprite);

      exports.Map = Map;
    }, {}],
    8: [function (require, module, exports) {
      "use strict";

      var __extends = this && this.__extends || function () {
        var extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return function (d, b) {
          extendStatics(d, b);

          function __() {
            this.constructor = d;
          }

          d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
      }();

      Object.defineProperty(exports, "__esModule", {
        value: true
      }); //ユーザー選択用エンティティ

      var SelectE =
      /** @class */
      function (_super) {
        __extends(SelectE, _super);

        function SelectE(scene) {
          var _this = _super.call(this, {
            scene: scene,
            local: true
          }) || this;

          _this.mode = 0;
          _this.playerIds = [];
          _this.mode = 1;
          var timeLimit = 20;
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.Monospace,
            size: 24
          });
          var title = new g.Sprite({
            scene: scene,
            src: scene.assets["title"],
            x: 70
          });

          _this.append(title);

          var label = new g.Label({
            scene: scene,
            text: "",
            font: font,
            fontSize: 24,
            textColor: "white",
            x: 0,
            y: 270,
            width: 640,
            widthAutoAdjust: false,
            textAlign: g.TextAlign.Center,
            local: true
          });

          _this.append(label); //参加人数


          var labelCnt = new g.Label({
            scene: scene,
            text: "",
            font: font,
            fontSize: 30,
            x: 120,
            y: 290,
            textColor: "white",
            local: true
          });

          _this.append(labelCnt); //受付時間表示用


          var labelTime = new g.Label({
            scene: scene,
            font: font,
            text: "",
            fontSize: 30,
            textColor: "white",
            x: 450,
            y: 290
          });

          _this.append(labelTime); //参加ボタン


          var btn = new g.FilledRect({
            scene: scene,
            x: 240,
            y: 280,
            width: 160,
            height: 60,
            cssColor: "yellow",
            touchable: true,
            local: true
          });
          btn.hide();

          _this.append(btn);

          _this.button = btn;
          var labelAddUser = new g.Label({
            scene: scene,
            font: font,
            text: "参加",
            fontSize: 24,
            textColor: "black",
            x: 30,
            y: 15
          });
          btn.append(labelAddUser); //受付開始ボタン

          var btnStart = new g.FilledRect({
            scene: scene,
            x: 240,
            y: 280,
            width: 160,
            height: 60,
            cssColor: "yellow",
            touchable: true,
            local: true
          });
          btnStart.hide();

          _this.append(btnStart);

          _this.button = btn;
          var labelStart = new g.Label({
            scene: scene,
            font: font,
            text: "受付開始",
            fontSize: 24,
            textColor: "black",
            x: 30,
            y: 15
          });
          btnStart.append(labelStart); //受付開始

          btnStart.pointDown.add(function (e) {
            if (g.game.vars.id === e.player.id) {
              //this.playerIds.push(e.player.id);
              btn.tag = e.player.id;
              g.game.raiseEvent(new g.MessageEvent({
                msg: "aggre"
              }));
            }
          }); //参加ユーザーをセット

          scene.message.add(function (msg) {
            if (!msg.data || msg.data.msg != "set_user") return;

            _this.playerIds.push(msg.player.id);

            labelCnt.text = _this.playerIds.length + 1 + "人";
            labelCnt.invalidate();
            console.log(_this.playerIds);
          });
          scene.message.add(function (msg) {
            if (!msg.data || msg.data.msg != "aggre") return;
            console.log(btn.tag);
            if (!btn.tag) btn.show();
            btnStart.hide();

            _this.start();
          });
          scene.message.add(function (msg) {
            if (!msg.data || msg.data.msg != "init") return;
            _this.playerIds.length = 0;
            label.text = "";
            label.invalidate();
            time = timeLimit;
          }); //受付開始待ち

          _this.init = function () {
            if (g.game.selfId === g.game.vars.id) {
              g.game.raiseEvent(new g.MessageEvent({
                msg: "init"
              }));
              btnStart.show();
            }
          };

          btn.pointDown.add(function (e) {
            btn.tag = e.player.id;
            btn.touchable = false;
            labelAddUser.text = "参加済";
            labelAddUser.invalidate();
            g.game.raiseEvent(new g.MessageEvent({
              msg: "set_user"
            }, e.player));
          });
          var time = timeLimit;

          _this.start = function () {
            var intervalId = scene.setInterval(function () {
              var _a;

              labelTime.text = "" + time;
              labelTime.invalidate();
              time--;

              if (time == -1) {
                if (_this.playerIds.length >= 1) {
                  //シャッフル
                  var m = _this.playerIds.length;

                  while (m) {
                    m--;
                    var i = g.game.random.get(0, m);
                    _a = [_this.playerIds[i], _this.playerIds[m]], _this.playerIds[m] = _a[0], _this.playerIds[i] = _a[1];
                  }

                  var index = _this.playerIds.indexOf(btn.tag);

                  if (btn.tag === g.game.vars.id) {
                    label.text = "放送者です";
                  } else if (index != -1) {
                    if (_this.mode === 0) {
                      if (index < 2) {
                        label.text = "当選しました";
                      } else {
                        label.text = "落選しました";
                      }
                    }

                    if (_this.mode === 1) {
                      label.text = "当選しました";
                    }
                  } else {
                    label.text = "参加しませんでした";
                  }

                  label.invalidate();
                  btn.hide();
                  scene.setTimeout(function () {
                    if (btn.tag === g.game.vars.id) {
                      g.game.raiseEvent(new g.MessageEvent({
                        msg: "start"
                      }));
                    }
                  }, 3000);
                } else {
                  btn.hide();
                  label.text = "参加者が足りませんでした";
                  label.invalidate();
                  labelTime.text = "";
                  labelTime.invalidate();
                  scene.setTimeout(function () {
                    _this.init();
                  }, 3000);
                }

                scene.clearInterval(intervalId);
              }
            }, 1000);
          };

          _this.getIndex = function () {
            return _this.playerIds.indexOf(btn.tag);
          };

          return _this;
        }

        return SelectE;
      }(g.E);

      exports.SelectE = SelectE;
    }, {}],
    9: [function (require, module, exports) {
      "use strict";

      var SelectE_1 = require("./SelectE");

      var Ghost_1 = require("./Ghost");

      var Map_1 = require("./Map");

      function main(param) {
        var lastJoinedPlayerId = null;
        var select;
        g.game.join.addOnce(function (ev) {
          lastJoinedPlayerId = ev.player.id;
          g.game.vars.id = ev.player.id;
          scene.append(select);
          select.init();
        });
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["title", "help", "win", "helpbtn", "ghost", "ghost2", "map", "test", "img_numbers_n", "anchor", "bgm", "se_start", "se_timeup", "se_move", "bell", "knight", "zombie", "king"]
        });

        var tl = require("@akashic-extension/akashic-timeline");

        scene.loaded.add(function () {
          var _a;

          var timeline = new tl.Timeline(scene);
          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: g.FontFamily.Monospace,
            size: 30
          }); //背景

          var bg = new g.FilledRect({
            scene: scene,
            cssColor: "darkblue",
            opacity: 0.9,
            width: 640,
            height: 360
          });
          scene.append(bg); //ヘルプ

          var sprHelp = new g.Sprite({
            scene: scene,
            src: scene.assets["help"],
            x: 70,
            touchable: true,
            local: true
          });
          sprHelp.hide();
          sprHelp.pointDown.add(function () {
            if (sprHelp.state == 1) {
              scene.append(sprHelp); //重ね順の関係でここでappend;

              sprHelp.show();
            } else {
              sprHelp.hide();
            }
          });
          var btnHelp = new g.Sprite({
            scene: scene,
            src: scene.assets["helpbtn"],
            x: 595,
            y: 5,
            touchable: true,
            local: true
          });
          scene.append(btnHelp);
          btnHelp.pointDown.add(function () {
            if (sprHelp.state == 1) {
              scene.append(sprHelp); //重ね順の関係でここでappend;

              sprHelp.show();
            } else {
              sprHelp.hide();
            }
          }); //バージョン表示

          var labelVersion = new g.Label({
            scene: scene,
            text: "ver.1.0",
            font: font,
            fontSize: 20,
            textColor: "white",
            x: 0,
            y: 305
          });
          scene.append(labelVersion); //トータル時間表示

          var totalTime = 0;
          var labelTotalTime = new g.Label({
            scene: scene,
            text: "0:00",
            font: font,
            fontSize: 20,
            textColor: "white",
            x: 0,
            y: 330
          });
          scene.append(labelTotalTime); //トータルタイム計測・表示

          scene.update.add(function () {
            totalTime++;
            var totalSec = Math.floor(totalTime / 30);
            var sec = totalSec % 60;
            var min = Math.floor(totalSec / 60);
            labelTotalTime.text = ("00" + min).slice(-2) + ":" + ("00" + sec).slice(-2);
            labelTotalTime.invalidate();
          });
          var uiBase = new g.E({
            scene: scene
          });
          uiBase.hide();
          scene.append(uiBase); //矢印表示用

          var sprAnchorBox = new g.FilledRect({
            scene: scene,
            cssColor: "white",
            width: 90,
            height: 45,
            x: 550,
            y: 310,
            local: true
          });
          uiBase.append(sprAnchorBox);
          var anchorNum = 0;
          var sprBtn = new g.FrameSprite({
            scene: scene,
            src: scene.assets["anchor"],
            width: 80,
            height: 40,
            x: 5,
            y: 5,
            touchable: true,
            local: true,
            frames: [0, 1]
          });
          sprAnchorBox.append(sprBtn);
          sprBtn.pointDown.add(function () {
            anchorNum = (anchorNum + 1) % 2;
            sprBtn.frameNumber = anchorNum;
            sprBtn.modified();
          }); //放送者・視聴者

          var strPlayers = ["放送者", "視聴者"];

          for (var i = 0; i < 2; i++) {
            var label = new g.Label({
              scene: scene,
              text: strPlayers[i],
              font: font,
              fontSize: 20,
              textColor: "white",
              x: 160 + i * 260,
              y: 0
            });
            uiBase.append(label);
          }

          var labelCnt = new g.Label({
            scene: scene,
            text: "0手目",
            font: font,
            fontSize: 20,
            textColor: "white",
            x: 290,
            y: 0
          });
          uiBase.append(labelCnt); //あなたの番ですと表示する用

          var labelPlayer = new g.Label({
            scene: scene,
            text: "",
            font: font,
            fontSize: 20,
            textColor: "yellow",
            x: 450,
            y: 0
          });
          scene.append(labelPlayer);
          var glyph = JSON.parse(scene.assets["test"].data);
          var numFont = new g.BitmapFont({
            src: scene.assets["img_numbers_n"],
            map: glyph.map,
            defaultGlyphWidth: glyph.width,
            defaultGlyphHeight: glyph.height,
            missingGlyph: glyph.missingGlyph
          }); //タイムリミット

          var labelTime = new g.Label({
            scene: scene,
            text: "",
            font: numFont,
            fontSize: 30,
            x: 20,
            y: 30
          });
          scene.append(labelTime); //勝利メッセージ用

          var sprWin = new g.FrameSprite({
            scene: scene,
            src: scene.assets["win"],
            width: 500,
            height: 250,
            x: 70,
            y: 50,
            frames: [0, 1]
          });
          var tekazu = 0;

          var callUser = function callUser() {
            if (turn === 0 && select.button.tag === lastJoinedPlayerId || turn === 1 && select.getIndex() === playerIndex) {
              labelPlayer.text = "あなたの番です";
              scene.assets["bell"].play().changeVolume(0.6);
            } else {
              labelPlayer.text = "";
            }

            time = timelimit;
            labelPlayer.x = turn * 500;
            labelPlayer.invalidate();
            labelTime.x = turn * 570 + 10;
            labelTime.text = "" + timelimit;
            labelTime.invalidate();
            tekazu++;
            labelCnt.text = "" + tekazu + "手目";
            labelCnt.invalidate();
          }; //時間表示(1秒おき)


          var timelimit = 20;
          var time = 0;
          var isStart = false;
          scene.setInterval(function () {
            if (isStart) {
              if (time >= 0) {
                labelTime.text = "" + time;
                labelTime.invalidate();
                time--;
              } else {
                if (!isMove) {
                  moveAuto();
                }
              }
            }
          }, 1000); //ゲームスタートの処理

          scene.message.add(function (msg) {
            if (!msg.data || msg.data.msg != "start") return;
            select.hide();
            var index = select.getIndex();

            if (select.mode === 0) {
              if (index != -1 && index < 2) {
                ghosts.forEach(function (e) {
                  if (e.turn === index) e.hideMask();
                });
              }
            }

            if (select.mode === 1) {
              if (lastJoinedPlayerId === select.button.tag) {
                ghosts.forEach(function (e) {
                  if (e.turn === 0) e.hideMask();
                });
              } else if (index != -1) {
                ghosts.forEach(function (e) {
                  if (e.turn === 1) e.hideMask();
                });
              }
            }

            if (lastJoinedPlayerId !== select.button.tag && index === -1) {
              sprAnchorBox.hide();
            }

            uiBase.show();
            mapBase.show();
            btnHelp.opacity = 0.3;
            btnHelp.modified();
            isStart = true;
            clearMaps();
            callUser();
            scene.assets["se_start"].play().changeVolume(1.0);
          });
          select = new SelectE_1.SelectE(scene);
          var mapBase = new g.E({
            scene: scene,
            x: 100,
            y: -25,
            width: 55 * 8,
            height: 55 * 8,
            touchable: true,
            local: true
          });
          mapBase.hide(); //マップ作成

          var ghostCnt = [[0, 0], [0, 0]];
          var maps = [];
          var width = 8;
          var height = 8;

          for (var y = 0; y < height; y++) {
            maps[y] = [];

            for (var x = 0; x < width; x++) {
              var map = new Map_1.Map({
                scene: scene,
                x: 55 * x,
                y: 55 * y,
                width: 55,
                height: 55,
                src: scene.assets["map"],
                frames: [0, 1]
              });
              maps[y][x] = map;
            }
          } //番兵以外表示


          for (var y = 1; y < height - 1; y++) {
            for (var x = 0; x < width; x++) {
              if (y === 1 || y === 6 || x > 0 && x < 7) {
                maps[y][x].num = 1;
                mapBase.append(maps[y][x]);
              }
            }
          } //取ったおばけ置き場作成


          var pickGhosts = [];

          for (var i = 0; i < 2; i++) {
            pickGhosts[i] = [];

            for (var j = 0; j < 2; j++) {
              pickGhosts[i][j] = [];

              for (var k = 0; k < 4; k++) {
                var rect = new g.FilledRect({
                  scene: scene,
                  x: i * 520 + k % 2 * 45 - 85,
                  y: 80 + j * 120 + Math.floor(k / 2) * 45 + 35,
                  width: 45 - 1,
                  height: 45 - 1,
                  cssColor: "gray"
                });
                pickGhosts[i][j][k] = rect;
                mapBase.append(rect);
              }
            }
          }

          scene.append(mapBase); //重ね順の関係でここでappend
          //矢印

          var anchorCnt = 0;
          var sprAnchors = [];

          for (var i = 0; i < 5; i++) {
            var sprAnchor = new g.FrameSprite({
              scene: scene,
              width: 80,
              height: 40,
              src: scene.assets["anchor"],
              frames: [0, 1],
              frameNumber: 0,
              opacity: 0.0
            });
            mapBase.append(sprAnchor);
            sprAnchors.push(sprAnchor);
          } //おばけ作成


          var ghosts = [];

          for (var i = 0; i < 16; i++) {
            var ghost = new Ghost_1.Ghost(scene);
            mapBase.append(ghost);
            ghosts[i] = ghost;
          } //おばけを並べる


          var cnt = 0;

          for (var i = 0; i < 2; i++) {
            //シャッフル
            var arr = [0, 0, 0, 0, 1, 1, 1, 1];
            var m = arr.length;

            while (m) {
              m--;
              var i_1 = g.game.random.get(0, m);
              _a = [arr[i_1], arr[m]], arr[m] = _a[0], arr[i_1] = _a[1];
            }

            for (var y = 2; y < 6; y++) {
              for (var x = 0; x < 2; x++) {
                var ghost = ghosts[cnt];
                var num = arr[cnt % 8];
                ghost.init(i, num);
                var map = maps[y][x + 1 + i * 4];
                ghost.x = map.x;
                ghost.y = map.y;
                ghost.modified();
                map.ghost = ghost;
                cnt++;
              }
            }
          } //玉座を配置


          var kingPos = [{
            x: 0,
            y: 1,
            n: 0
          }, {
            x: 0,
            y: 6,
            n: 0
          }, {
            x: 7,
            y: 1,
            n: 1
          }, {
            x: 7,
            y: 6,
            n: 1
          }];
          kingPos.forEach(function (p) {
            var map = maps[p.y][p.x];
            map.frameNumber = 1;
            map.modified();
            var ghost = new Ghost_1.Ghost(scene);
            mapBase.append(ghost);
            ghost.x = map.x;
            ghost.y = map.y;
            ghost.init(p.n, 2);
            ghost.hideMask();
            map.ghost = ghost;
          }); //盤面の移動範囲をクリア(仮)

          function clearMaps() {
            for (var y = 0; y < height; y++) {
              for (var x = 0; x < width; x++) {
                if (maps[y][x].num === 2 || maps[y][x].num === 1) {
                  maps[y][x].num = 1;
                  maps[y][x].frameNumber = 0;
                  maps[y][x].modified();
                }

                if (maps[y][x].ghost && maps[y][x].ghost.turn === turn) {
                  maps[y][x].frameNumber = 1;
                  maps[y][x].modified();
                }
              }
            }
          }

          var nowGhost;
          var py = -1;
          var px = -1;
          var turn = 0;
          var dx = [-1, 0, 1, 0];
          var dy = [0, 1, 0, -1];
          var isMove = false; //移動

          var move = function move(x, y) {
            isMove = true; //相手のおばけがいる時

            var isGhost = false;
            var gameState = 0; //0:継続 1:勝ち 2:負け

            if (maps[y][x].ghost) {
              var ghost_1 = maps[y][x].ghost;

              if (maps[y][x].ghost.num != 2) {
                //取る処理
                mapBase.append(ghost_1);
                var num = ghostCnt[turn][ghost_1.num];
                var mx = pickGhosts[turn][ghost_1.num][num].x;
                var my = pickGhosts[turn][ghost_1.num][num].y;
                timeline.create(ghost_1).wait(1000).moveTo(mx, my, 500);
                ghostCnt[turn][ghost_1.num]++;
                ghost_1.player.show();

                if (ghostCnt[turn][ghost_1.num] == 4) {
                  gameState = ghost_1.num + 1;
                }

                timeline.create(ghost_1.mask).moveBy(0, -60, 300).wait(500).call(function () {
                  if (ghost_1.num === 0) {
                    scene.assets["knight"].play().changeVolume(0.6);
                  } else {
                    scene.assets["zombie"].play().changeVolume(0.6);
                  }

                  ghost_1.mask.hide();
                });
                ghost_1.modified();
                isGhost = true;
              } else {
                gameState = 1;
                mapBase.append(ghost_1);
                timeline.create(ghost_1).moveBy(turn === 1 ? -55 : 55, 0, 300).con().rotateBy(turn === 1 ? -90 : 90, 300).call(function () {
                  scene.assets["king"].play().changeVolume(0.6);
                });
              }
            }

            maps[y][x].ghost = maps[py][px].ghost;
            maps[py][px].ghost = null;

            function next() {
              if (gameState === 0) {
                callUser();
              } else {
                if (gameState === 1) {
                  labelPlayer.text = (turn === 0 ? "放送者" : "視聴者") + "の勝ち";
                  sprWin.frameNumber = turn;
                } else {
                  labelPlayer.text = (turn === 0 ? "視聴者" : "放送者") + "の勝ち";
                  sprWin.frameNumber = (turn + 1) % 2;
                }

                sprWin.modified();
                scene.append(sprWin);
                isStart = false;
                sprWin.scale(0.0);
                timeline.create(sprWin).wait(1000).call(function () {
                  scene.assets["se_timeup"].play().changeVolume(1.0);
                }).scaleTo(1.0, 1.0, 500).wait(6000).call(function () {
                  sprWin.hide();
                });
                ghosts.forEach(function (e) {
                  e.mask.opacity = 0.5;
                  e.player.show();
                  e.modified();
                });
              }

              labelPlayer.invalidate();
              isMove = false;
            }

            timeline.create(nowGhost).wait(isGhost ? 1000 : 100).moveTo(maps[y][x].x, maps[y][x].y, 300).call(function () {
              next();
            });

            if (gameState === 0) {
              turn = (turn + 1) % 2;

              if (turn === 1) {
                playerIndex = (playerIndex + 1) % select.playerIds.length;
              }
            }

            scene.assets["se_move"].play().changeVolume(0.6);
            nowGhost = undefined;
            clearMaps(); //仮
          }; //移動範囲表示


          var arrMovePos = [];

          var showMoveArea = function showMoveArea(x, y) {
            clearMaps(); //仮

            nowGhost = maps[y][x].ghost;
            arrMovePos.length = 0;

            for (var i = 0; i < 4; i++) {
              var xx = x + dx[i];
              var yy = y + dy[i];
              var map = maps[yy][xx];

              if (map.num === 1 && (!map.ghost || map.ghost.turn === (turn + 1) % 2 && map.ghost.num != 2 || map.ghost.turn === (turn + 1) % 2 && nowGhost.num === 0 && map.ghost.num === 2)) {
                map.num = 2;
                map.frameNumber = 1;
                map.modified();
                arrMovePos.push({
                  x: xx,
                  y: yy
                });
              }
            }

            px = x;
            py = y;
          }; //自動移動


          var moveAuto = function moveAuto() {
            var arr = [];

            for (var y = 0; y < height; y++) {
              for (var x = 0; x < height; x++) {
                var map = maps[y][x];

                if (map.ghost && map.ghost.turn === turn && map.ghost.num != 2) {
                  arr.push({
                    x: x,
                    y: y
                  });
                }
              }
            }

            while (true) {
              var num = g.game.random.get(0, arr.length - 1);
              var pos = arr[num];
              showMoveArea(pos.x, pos.y);

              if (arrMovePos.length != 0) {
                var movePos = arrMovePos[g.game.random.get(0, arrMovePos.length - 1)];
                move(movePos.x, movePos.y);
                break;
              }
            }
          }; //手動移動


          scene.message.add(function (msg) {
            if (!msg.data || msg.data.msg != "move") return;
            var x = msg.data.x;
            var y = msg.data.y;

            if (maps[y][x].ghost && maps[y][x].ghost.num != 2 && maps[y][x].ghost.turn == turn) {
              //移動エリア表示
              showMoveArea(x, y);
            } else if (maps[y][x].num === 2) {
              //移動
              move(x, y);
            }
          });
          scene.message.add(function (msg) {
            if (!msg.data || msg.data.msg != "set_anchor") return;
            var x = msg.data.x;
            var y = msg.data.y;
            var anchor = sprAnchors[anchorCnt];
            timeline.remove(anchor.tag);
            anchor.x = x;
            anchor.y = y - anchor.height;
            anchor.frameNumber = msg.data.color;
            anchor.opacity = 1;
            mapBase.append(anchor);
            anchor.modified();
            var tween = timeline.create().wait(1000).every(function (a, b) {
              anchor.opacity = 1 - b;
              anchor.modified();
            }, 1000);
            anchor.tag = tween;
            anchorCnt = (anchorCnt + 1) % sprAnchors.length;
          });
          var playerIndex = 0;
          mapBase.pointDown.add(function (e) {
            if (!isStart) return;

            if (turn === 0 && select.button.tag === lastJoinedPlayerId || turn === 1 && select.getIndex() === playerIndex) {
              var x = Math.floor(e.point.x / 55);
              var y = Math.floor(e.point.y / 55);
              g.game.raiseEvent(new g.MessageEvent({
                msg: "move",
                x: x,
                y: y
              }));
            } else if (select.getIndex() != -1 || select.button.tag === lastJoinedPlayerId) {
              g.game.raiseEvent(new g.MessageEvent({
                msg: "set_anchor",
                x: e.point.x,
                y: e.point.y,
                color: anchorNum
              }));
            }
          });
          scene.assets["bgm"].play().changeVolume(0.4);
        });
        g.game.pushScene(scene);
      }

      module.exports = main;
    }, {
      "./Ghost": 6,
      "./Map": 7,
      "./SelectE": 8,
      "@akashic-extension/akashic-timeline": 5
    }]
  }, {}, [9])(9);
});